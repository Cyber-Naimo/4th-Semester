#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

sem_t icecream, payment;

int remaining;

void* person(void* arg) {
    int id = *(int*)arg;
    printf("\nPerson %d entering contest\n\n", id);

    while (1) {
        
        sem_wait(&icecream);

        // Check if ice cream is available
        if (remaining <= 0) {
            sem_post(&icecream);
            break;
        }

        sem_wait(&payment);
        int money = rand() % 100;
        printf("Person %d counted %d money in the wallet\n", id, money);

        // Buy an ice cream cone and decreament remaining ice creams
        remaining--;
        printf("Person %d ate an ice cream cone\n", id);

        sem_post(&payment);
        sem_post(&icecream);
    }

    printf("\nPerson %d finished contest\n", id);

    pthread_exit(NULL);
}

int main()
{
	pthread_t persons[3];
	int ids[3];

	sem_init(&icecream, 0, 1);
	sem_init(&payment, 0, 1);

	remaining = 15;

	// Create threads for each person
	for (int i = 0; i < 3; i++) {
	ids[i] = i + 1;
	pthread_create(&persons[i], NULL, person, &ids[i]);
	}

	for (int i = 0; i < 3; i++) 
	{
		pthread_join(persons[i], NULL);
	}

	sem_destroy(&icecream);
	sem_destroy(&payment);
}

