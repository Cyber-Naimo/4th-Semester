#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
sem_t weighting;
sem_t seceurity ;
sem_t boarding ;
void *airport(void *argc)
{
	int num = *(int *) argc;
	// first customer came to the weight the luagage and wait for 4 seconds after that move the customer to the seceurity check
	printf("\nCustomer %d came in the weighting Room.\n",num); 
	sem_wait(&weighting);
	sleep(4);
	sem_post(&weighting);
	printf("\nCustomer %d going in the Seceurity Room.\n",num);
	
	// secondly customer came to the seceurity check to weight the luagage and wait for 7 seconds and move the customer to the boarding pass
	printf("\nCustomer %d came in the Seceurity Room.\n",num);
	sem_wait(&seceurity);
	sleep(7);
	sem_post(&seceurity);
	printf("\nCustomer %d going in the Boarding Room.\n",num);
	
	// thirdly customer came to the boarding pass and wait for 7 seconds
	printf("\nCustomer %d came in the Boarding Room.\n",num);
	sem_wait(&boarding);
	sleep(3);
	sem_post(&boarding);
	printf("\nCustomer %d going in the for the Flight. Thank You! %d for corperating with us.\n",num,num);
	pthread_exit(NULL);
}
int main ()
{
	int N=3;
	// threads for the customers we have here 10 max
 	pthread_t arr[N];
 	int index[N];
 	sem_init(&weighting,0,1);
	sem_init(&seceurity,0,1);
	sem_init(&boarding,0,1);
 	for(int i=1;i<=N;i++)
 	{
 		index[i] = i;
 		pthread_create(&arr[i],NULL,airport,&index[i]);
	}
	
	
 	for(int i=1;i<=N;i++)
 	{
 		pthread_join(arr[i],NULL);
	}
	return 0;
}
