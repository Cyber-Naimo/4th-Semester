#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include<semaphore.h>
#define N_TICKETS 6      // no of tickets availabe to sold
#define N_SELLERS 2		// no of seller

sem_t sema;
int sold_tickets = 0;
int available_tickets = N_TICKETS;

void* sell_tickets(void* argc) {
    int seller_id = (int)argc;
    int n_sold = 0;
    while (1)
    {
    	// entering in the critical section
        sem_wait(&sema);
        //now selling is performed
        if (available_tickets > 0)
        {
            available_tickets--;++
            sold_tickets++;
            n_sold++;
            printf("Seller %d sold ticket %d\n", seller_id, sold_tickets);
        }
        sem_post(&sema);
        if (available_tickets == 0)
        {
            break;
        }
    }
    printf("Seller %d sold %d tickets\n", seller_id, n_sold);
    pthread_exit(NULL);
}

int main() 
{
	// semaphore initialiazation    0 in middle means its not shared , and 1 means at right sems initial value;
    sem_init(&sema, 0,1);
    pthread_t threads[N_SELLERS];
    int seller_ids[N_SELLERS];
    for (int i = 0; i < N_SELLERS; i++)
    {
    	// giving each seller a no so we can identify which seller sold which ticket
        seller_ids[i] = i + 1;
        pthread_create(&threads[i], NULL, sell_tickets, &seller_ids[i]);
    }
    for (int i = 0; i < N_SELLERS; i++)
    {
        pthread_join(threads[i], NULL);
    }
    sem_destroy(&sema);
    return 0;
}
